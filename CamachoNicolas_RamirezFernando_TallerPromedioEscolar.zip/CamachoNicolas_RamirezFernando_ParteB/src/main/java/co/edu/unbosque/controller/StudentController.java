package co.edu.unbosque.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.edu.unbosque.model.Student;
import co.edu.unbosque.service.StudentService;
import co.edu.unbosque.util.AESUtil;

import org.springframework.http.MediaType;
import jakarta.transaction.Transactional;

@RestController
@RequestMapping("/Student")
@CrossOrigin(origins = { "http://localhost:8080", "http://localhost:8081", "*" })
@Transactional

public class StudentController {
	@Autowired
	private StudentService studentServ;

	public StudentController() {

	}

	@PostMapping(path = "/createStudentjson", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> createNewStudentWithJson(@RequestBody Student newStudent) {
		Student temp = new Student(AESUtil.decrypt2(newStudent.getStudentName()),
				AESUtil.decrypt2(newStudent.getNota1()), AESUtil.decrypt2(newStudent.getNota2()),
				AESUtil.decrypt2(newStudent.getNota3()));
		int status = studentServ.create(temp);
		if (status == 0) {
			double finalGrade = studentServ.calculateAverage(temp);

			if (finalGrade == 3) {
				return new ResponseEntity<String>("Tres es nota lo demás es lujo " + finalGrade, HttpStatus.ACCEPTED);
			} else if (finalGrade > 3) {
				return new ResponseEntity<String>("Vos no serás Einstein " + finalGrade, HttpStatus.ACCEPTED);
			} else if (finalGrade < 3) {
				return new ResponseEntity<String>("Tocó poner cola bro " + finalGrade, HttpStatus.ACCEPTED);
			}

			return new ResponseEntity<String>("Student created successfully", HttpStatus.CREATED);
		} else {
			return new ResponseEntity<String>("Error creating the Student", HttpStatus.NOT_ACCEPTABLE);
		}
	}

	@GetMapping(path = "/getall")
	public ResponseEntity<List<Student>> getAll() {
		List<Student> students = studentServ.getAll();
		if (students.isEmpty()) {
			return new ResponseEntity<List<Student>>(students, HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<List<Student>>(students, HttpStatus.ACCEPTED);
		}
	}
	
	

}
