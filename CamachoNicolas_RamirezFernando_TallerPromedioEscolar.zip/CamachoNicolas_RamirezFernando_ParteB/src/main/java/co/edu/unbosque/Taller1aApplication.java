package co.edu.unbosque;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Taller1aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Taller1aApplication.class, args);
	}

}
